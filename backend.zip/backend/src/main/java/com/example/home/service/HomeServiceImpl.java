package com.example.home.service;

import com.example.users.model.UserProfile;
import com.example.users.service.UserProfileService;
import org.springframework.stereotype.Service;

@Service
public class HomeServiceImpl implements HomeService {

    private UserProfileService userService; 

    public HomeServiceImpl(UserProfileService userService){
        this.userService = userService;
    }

    @Override
    public UserProfile getUserProfile(Long userId) {
        return userService.getUserProfile(userId);
    }

    @Override
    public UserProfile saveOrUpdateUserProfile(UserProfile profile) {
        return userService.saveOrUpdateProfile(profile);
    }

    @Override
    public UserProfile saveOrUpdateUserProfile() {
        UserProfile profile = new UserProfile();
        profile.setName("John Doe");
        profile.setDescription("Sou um desenvolvedor fullstack, formando em Ciência da Computação, possuo experiência de 2 anos e 2 meses com C#, SQL Server, VB.NET e JavaScript na LG Lugar de Gente. Atualmente estou estudando Java utilizando Spring com hibernate, Angular e Flutter, que inclusive são as tecnologias utilizadas para montar esse site.");

        return userService.saveOrUpdateProfile(profile);
    }
}
